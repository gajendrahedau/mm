package com.cg.project.stepdefinition;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class GoogleSearchStepDefinition {
	@Given("^User is in on Google HomePage$")
	public void user_is_in_on_Google_HomePage() throws Throwable {
	}
	@When("^User search for 'Agile Methodology'$")
	public void user_search_for_Agile_Methodology() throws Throwable {
	}
	@Then("^All links should diplay with 'Agile Methodology'$")
	public void all_links_should_diplay_with_Agile_Methodology() throws Throwable {
	}
}
