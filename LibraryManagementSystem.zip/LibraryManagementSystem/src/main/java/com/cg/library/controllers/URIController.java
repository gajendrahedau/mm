package com.cg.library.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.cg.library.beans.Book;
import com.cg.library.beans.Student;
import com.cg.library.services.LibraryService;


@Controller
public class URIController {
	Student student;
	@Autowired
	LibraryService libraryService;
	
	@RequestMapping("/")
	public String getIndexPage(){
		Book book1=new Book(1234, "Let us C", "yashwant kanetkar", "available");
		libraryService.saveBookDetails(book1);
		Book book2=new Book(1235, "Let us C++", "aparajita malhotra", "available");
		libraryService.saveBookDetails(book2);
		Book book3=new Book(1236, "Let us Java", "gajjarnet hedau", "available");
		libraryService.saveBookDetails(book3);
		Book book4=new Book(1237, "Let us Python", "atul anand", "available");
		libraryService.saveBookDetails(book4);
		Book book5=new Book(1238, "Let us R", "amisha verma", "available");
		libraryService.saveBookDetails(book5);
		return "indexPage";
	}
	@RequestMapping("/acceptStudentDetails")
	public String getAcceptStudentDetailsPage(){
		return "acceptStudentDetailsPage";
	}
	
	
	@RequestMapping("/getStudentDetails")
	public String getStudentDetailsPage(){
		return "getStudentDetailsPage";
	}
	@RequestMapping("/getBookDetails")
	public String getBookDetailsPage(){
		return "getBookDetailsPage";
	}
	@RequestMapping("/getAllBookDetails")
	public ModelAndView getAllBookDetailsPage(){
		List<Book>listOfBooks=libraryService.getAllBookDetails();
		return new ModelAndView("getAllBookDetailsPage","listOfBooks",listOfBooks);
	}
	@RequestMapping("/bookIssue")
	public String getBookIssuePage(){
		return "bookIssuePage";
	}
	@RequestMapping("/deleteStudentDetails")
	public String getDeleteStudentDetailsPage(){
		return "deleteStudentDetailsPage";
	}
	@RequestMapping("/deleteBookDetails")
	public String getDeleteBookDetailsPage(){
		return "deleteBookDetailsPage";
	}
	
	@ModelAttribute
	public Student getStudent() {
		student= new Student();
		return student;
	}
}
