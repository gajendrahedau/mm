package com.cg.library.services;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.library.beans.Book;
import com.cg.library.beans.Student;
import com.cg.library.beans.Transaction;
import com.cg.library.daoservices.BookDAO;
import com.cg.library.daoservices.StudentDAO;
import com.cg.library.daoservices.TransactionDAO;
import com.cg.library.exceptions.BookNotFoundException;
import com.cg.library.exceptions.StudentDetailsNotFoundException;
@Component("libraryService")
public class LibraryServiceImpl implements LibraryService{
	@Autowired
	private BookDAO bookDAO;
	@Autowired
	private TransactionDAO transactionDAO;
	@Autowired
	private StudentDAO studentDAO;
	@Autowired
	LibraryService libraryService;
	@Override
	public Student acceptStudentDetails(Student student) {
		return studentDAO.save(student);
	}
	@Override
	public Student getStudentDetails(int studentID) throws StudentDetailsNotFoundException {
		return studentDAO.findById(studentID).orElseThrow(()->new StudentDetailsNotFoundException("Student with student ID "+studentID+" does not exist"));
	}
	@Override
	public Book getBookDetails(int bookID) throws BookNotFoundException {
		return bookDAO.findById(bookID).orElseThrow(()->new BookNotFoundException("Book with book ID "+bookID+" does not exist"));
	}
	@Override
	public List<Book> getAllBookDetails() {
		return bookDAO.findAll();
	}
	@Override
	public Transaction bookIssue(int studentID, int bookID) throws BookNotFoundException,StudentDetailsNotFoundException {
		getStudentDetails(studentID);
		getBookDetails(bookID);
		LocalDate date = LocalDate.now(); 
		Transaction transaction=new Transaction(date.toString(),date.plusDays(15).toString()); 
		transactionDAO.save(transaction);
		return transaction;
	}
	@Override
	public boolean deleteStudentDetails(int studentID) throws StudentDetailsNotFoundException {
		getStudentDetails(studentID);
		studentDAO.deleteById(studentID);
		return true;
	}
	@Override
	public boolean deleteBookDetails(int bookID) throws BookNotFoundException {
		Book book=getBookDetails(bookID);
		if(book==null)
			return false;
		bookDAO.deleteById(bookID);
		return true;
	}
	@Override
	public Book saveBookDetails(Book book) {
		bookDAO.save(book);
		return book;
	
	}
}
