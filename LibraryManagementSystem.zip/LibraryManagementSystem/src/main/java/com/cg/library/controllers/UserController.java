package com.cg.library.controllers;

import javax.naming.Binding;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.library.beans.Book;
import com.cg.library.beans.Student;
import com.cg.library.beans.Transaction;
import com.cg.library.exceptions.BookNotFoundException;
import com.cg.library.exceptions.StudentDetailsNotFoundException;
import com.cg.library.services.LibraryService;

@Controller
public class UserController {
	Student student;
	Book book;
	@Autowired
	LibraryService libraryService;
	
	@RequestMapping("/studentRegistration")
	public  ModelAndView registerStudentAction(@ModelAttribute Student student,BindingResult result){
		if(result.hasErrors())
			return new ModelAndView("acceptStudentDetailsPage");
		
		student=libraryService.acceptStudentDetails(student);
		return new ModelAndView("registrationSuccessPage","student",student);
	}	
	
	@RequestMapping("/showStudentDetails")
	public  ModelAndView showStudentAction(@RequestParam int studentID) throws StudentDetailsNotFoundException{
		String msg=null;
		try {
			student=libraryService.getStudentDetails(studentID);
			return new ModelAndView("showStudentDetailsPage","student",student);
		} catch (StudentDetailsNotFoundException e) {
			msg="Student details not found";
			return new ModelAndView("getStudentDetailsPage","message",msg);
		}
	}	
	
	@RequestMapping("/showBookDetails")
	public  ModelAndView showBookAction(@RequestParam int bookID) throws BookNotFoundException{
		String msg=null;
		try {
			book=libraryService.getBookDetails(bookID);
			return new ModelAndView("showBookDetailsPage","book",book);
		} catch (BookNotFoundException e) {
			msg="Book does not exist";
			return new ModelAndView("getBookDetailsPage","message",msg);
		}	
	}
	@RequestMapping("/newBookIssue")
	public  ModelAndView bookIssueAction(@RequestParam int bookID,@RequestParam int studentID ) throws BookNotFoundException,StudentDetailsNotFoundException{
		String msg=null;
		try {
		Transaction transaction=libraryService.bookIssue(studentID, bookID);
		return new ModelAndView("bookIssueSuccessPage","transaction",transaction);
		}catch (StudentDetailsNotFoundException e) {
			msg="Student details not found";
			return new ModelAndView("bookIssuePage","message",msg);
		}
		catch (BookNotFoundException e) {
			msg="Book does not exist";
			return new ModelAndView("bookIssuePage","message",msg);
		}
	}
	@SuppressWarnings("finally")
	@RequestMapping("/deleteStudent")
	public  ModelAndView deleteStudentAction(@RequestParam int studentID ) throws StudentDetailsNotFoundException{
		String msg=null;
		try {
			libraryService.deleteStudentDetails(studentID);
			 msg="Student details deleted";	
		}catch (StudentDetailsNotFoundException e) {
			msg="Student details not found";
		}finally {
			return new ModelAndView("deleteStudentDetailsPage","message",msg);
		}	
	}
	@SuppressWarnings("finally")
	@RequestMapping("/deleteBook")
	public  ModelAndView deleteBookAction(@RequestParam int bookID ) throws BookNotFoundException{
		String msg=null;
		try {
			libraryService.deleteBookDetails(bookID);
				 msg="Book details deleted";
		} catch (BookNotFoundException e) {
			msg="book does not exist.";
		}
		finally {
			return new ModelAndView("deleteBookDetailsPage","message",msg);
		}
	}
	
}
