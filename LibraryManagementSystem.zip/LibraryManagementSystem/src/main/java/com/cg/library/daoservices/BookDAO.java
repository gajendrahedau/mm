package com.cg.library.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.library.beans.Book;

public interface BookDAO extends JpaRepository<Book,Integer>{

}
