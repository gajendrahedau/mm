package com.cg.library.services;
import java.util.List;

import com.cg.library.beans.Book;
import com.cg.library.beans.Student;
import com.cg.library.beans.Transaction;
import com.cg.library.exceptions.BookNotFoundException;
import com.cg.library.exceptions.StudentDetailsNotFoundException;
public interface LibraryService {
	public Student acceptStudentDetails(Student student);
	public Student getStudentDetails(int studentID) throws StudentDetailsNotFoundException;
	public Book getBookDetails(int bookID) throws BookNotFoundException;
	public List<Book> getAllBookDetails();
	public Transaction bookIssue(int studentID,int bookID)  throws BookNotFoundException,StudentDetailsNotFoundException;
	public boolean deleteStudentDetails(int studentID) throws StudentDetailsNotFoundException;
	public boolean deleteBookDetails(int bookID)  throws BookNotFoundException;
	public Book saveBookDetails(Book book);
}
