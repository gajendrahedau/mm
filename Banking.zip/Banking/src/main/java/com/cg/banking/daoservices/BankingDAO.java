package com.cg.banking.daoservices;

public interface BankingDAO {

}
