package com.cg.banking.controllers;

public class UserController {

}
